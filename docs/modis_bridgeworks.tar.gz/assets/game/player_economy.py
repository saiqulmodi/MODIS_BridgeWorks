"""Player profile and economy tracker for rewards."""

class PlayerProfile:
    def __init__(self, name, phone="", email=""):
        self.name = name
        self.phone = phone
        self.email = email
        self.rupees = 0.0  # Must be initialized here!

    def read_content(self, content_id):
        # 1 Rs awarded for attending / exploring a question or concept
        self.rupees += 1.0

    def submit_answer(self, content_id, is_correct):
        if is_correct:
            # 10 Rs awarded for getting the right answer
            self.rupees += 10.0